<?php
// Include the database connection file
include('config.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $brand_id = $_POST['brand_id'];
    $price = $_POST['price'];

    // Insert data into the 'product' table
    $sql = "INSERT INTO product (code, name, brand_id, price) VALUES ('$code', '$name', '$brand_id', '$price')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Product details added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Retrieve brand data for dropdown
$brand_query = "SELECT id, name FROM brand";
$brand_result = $conn->query($brand_query);
$brands = $brand_result->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
</head>
<body>

<h2>Add Product</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="code">Code:</label>
    <input type="text" name="code" required><br>

    <label for="name">Name:</label>
    <input type="text" name="name" required><br>

    <label for="brand_id">Brand:</label>
    <select name="brand_id" required>
        <?php
        foreach ($brands as $brand) {
            echo "<option value='{$brand['id']}'>{$brand['name']}</option>";
        }
        ?>
    </select><br>

    <label for="price">Price:</label>
    <input type="text" name="price" required><br>

    <input type="submit" value="Add Product">
</form>

</body>
</html>
