<?php
// Include the database connection file
include('../config.php');

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    // Insert data into the 'brand' table
    $sql = "INSERT INTO brand (code, name, note) VALUES ('$code', '$name', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Brand details added successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Brand</title>
</head>
<body>

<h2>Add Brand</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <label for="code">Code:</label>
    <input type="text" name="code" required><br>

    <label for="name">Name:</label>
    <input type="text" name="name" required><br>

    <label for="note">Note:</label>
    <textarea name="note"></textarea><br>

    <input type="submit" value="Add Brand">
</form>

</body>
</html>
