<?php
// Include the database connection file
include('../../config.php');

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    // Insert data into the 'brand' table
    $sql = "INSERT INTO brand (code, name, note) VALUES ('$code', '$name', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'brandacula';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button id="brandPopBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                    <!--Add Brand Popup Form-->
                    <div class="popup-container" id="brandFormContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form vertical-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Brand Details</h2>
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Code</label><br>
                                        <input type="text" name="code">
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Name</label><br>
                                        <input type="text" name="name" required>
                                    </div>
                                    <div class="form-input note-input">
                                        <label for="">Description</label><br>
                                        <textarea name="note"></textarea>
                                    </div>
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeBrandForm" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, name, note FROM brand";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['name'];?></td>
                                <td><?php echo $row['note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn" id="brandViewPop">View</a>
                                            <a href="#" class="edit-btn" id="brandEditPop">Edit</a>
                                            <a href="#" class="filter-btn" id="brandFilterPop">Filter</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--for brand view-->
    <div class="edit-pop">
        <div class="popup-container" id="brandEditContainer">
            <div class="popup view-pop">
                <div class="popup-content">
    
                    <form action="" class="sub-form vertical-form">
                        <div class="form-input form-heading">
                            <h2>Edit Brand Details</h2>
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Code</label><br>
                            <input type="text" name="code">
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Name</label><br>
                            <input type="text" name="name" required>
                        </div>
                        <div class="form-input note-input">
                            <label for="">Description</label><br>
                            <textarea name="" id="" cols="42" rows="3"></textarea>
                        </div>
                        <div class="form-btns">
                            <div class="close-btn">
                                <button id="closeBrandEdit" class="close-btn">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button class="submit-btn">EDIT</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container" id="brandViewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Brand Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure>Whitedent</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">No. Of Products:</span>
                                <figure>31</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">No. Of Categories:</span>
                                <figure>4</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button id="closeBrandView" class="close-btn">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <!--filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="brandFilterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter Brand</h2>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Select Category</label><br>
                            <input list="categories" class="datalist-input" id="category" name="category" autocomplete="off" required>

                            <datalist id="categories">
                                <option value="Category A">
                                <option value="Category X">
                                <option value="Category i">
                            </datalist>
                        </div>
                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeBrandFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>




    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

            // FOR ADD-BRAND BUTTON ****
            $('#brandPopBtn').on('click', function () {
                $('#brandFormContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBrandForm').on('click', function () {
                $('#brandFormContainer').fadeOut();
            });

            $('#brandPopBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR EDIT-BRAND BUTTON ****
            $('#brandEditPop').on('click', function () {
                $('#brandEditContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBrandEdit').on('click', function () {
                $('#brandEditContainer').fadeOut();
            });

            $('#brandEditPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW-BRAND BUTTON ****
            $('#brandViewPop').on('click', function () {
                $('#brandViewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBrandView').on('click', function () {
                $('#brandViewContainer').fadeOut();
            });

            $('#brandViewPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER-BRAND BUTTON ****
            $('#brandFilterPop').on('click', function () {
                $('#brandFilterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBrandFilter').on('click', function () {
                $('#brandFilterContainer').fadeOut();
            });

            $('#brandFilterPop').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>