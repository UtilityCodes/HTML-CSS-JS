<?php
// Include the database connection file
include('../../config.php');

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    // Insert data into the 'brand' table
    $sql = "INSERT INTO service (code, name, note) VALUES ('$code', '$name', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Servicina';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="servicePopBtn" class="add-btn"><i class="fa fa-plus"></i></button>
                    <!--Add Brand Popup Form-->
                    <div class="popup-container" id="serviceFormContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form vertical-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Service Details</h2>
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Code</label><br>
                                        <input type="text" name="code">
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Name</label><br>
                                        <input type="text" name="name" required>
                                    </div>
                                    <div class="form-input note-input">
                                        <label for="">Description</label><br>
                                        <textarea name="note" cols="42" rows="3"></textarea>
                                    </div>
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeserviceForm" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, name, note FROM service";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['name'];?></td>
                                <td><?php echo $row['note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn" id="serviceViewPop">View</a>
                                            <a href="#" class="edit-btn" id="serviceEditPop">Edit</a>
                                            <a href="#" class="filter-btn" id="serviceFilterPop">Filter</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--for brand view-->
    <div class="edit-pop">
        <div class="popup-container" id="serviceEditContainer">
            <div class="popup view-pop">
                <div class="popup-content">
    
                    <form action="" class="sub-form vertical-form">
                        <div class="form-input form-heading">
                            <h2>Edit Service Details</h2>
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Code</label><br>
                            <input type="text" name="code">
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Name</label><br>
                            <input type="text" name="name" required>
                        </div>
                        <div class="form-input note-input">
                            <label for="">Description</label><br>
                            <textarea name="" id="" cols="42" rows="3"></textarea>
                        </div>
                        <div class="form-btns">
                            <div class="close-btn">
                                <button id="closeserviceEdit" class="close-btn">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button class="submit-btn">EDIT</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container" id="serviceViewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Service Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure>Wheel Alignment</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>239</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>

                        </div>

                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button id="closeserviceView" class="close-btn">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    <!--filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="serviceFilterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter service</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeserviceFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>




    



    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

            // FOR ADD BUTTON ****
            $('#servicePopBtn').on('click', function () {
                $('#serviceFormContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeserviceForm').on('click', function () {
                $('#serviceFormContainer').fadeOut();
            });

            $('#servicePopBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR EDIT BUTTON ****
            $('#serviceEditPop').on('click', function () {
                $('#serviceEditContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeserviceEdit').on('click', function () {
                $('#serviceEditContainer').fadeOut();
            });

            $('#serviceEditPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('#serviceViewPop').on('click', function () {
                $('#serviceViewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeserviceView').on('click', function () {
                $('#serviceViewContainer').fadeOut();
            });

            $('#serviceViewPop').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#serviceFilterPop').on('click', function () {
                $('#serviceFilterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeserviceFilter').on('click', function () {
                $('#serviceFilterContainer').fadeOut();
            });

            $('#serviceFilterPop').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>