<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Sale Return List';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <a href="add.php"> <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button></a>                 

                </div>
                <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Paid</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                <?php 
                   include('../../config.php');
                   $sql =  "SELECT 
                                sale_return.id as id,
                                sale_return.code as code, 
                                sale_return.dates as dates,
                                sale_return.product_id as product_id,
                                sale.price as price,
                                sale_return.quantity as quantity,
                                (sale.price * sale_return.quantity) - SUM(sr_pay.discount) as total_owed,
                                SUM(sr_pay.amount) as total_amount,
                                CASE
                                    WHEN (sale.price * sale_return.quantity) - SUM(sr_pay.discount) = SUM(sr_pay.amount) THEN 'complete'
                                    WHEN (sale.price * sale_return.quantity) - SUM(sr_pay.discount) > SUM(sr_pay.amount) THEN 'incomplete'
                                    WHEN SUM(sr_pay.amount) = 0 THEN 'not paid'
                                    ELSE ''
                                END AS status
                            FROM sale_return
                            INNER JOIN sr_pay ON sale_return.code = sr_pay.code
                            INNER JOIN sale ON sale_return.product_id = sale.product_id
                            GROUP BY sale_return.id
                            ORDER BY sale_return.dates ASC ";

                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['dates'];?></td>
                                <td><?php echo $row['status'];?></td>
                                <td class="td-amount"><?php echo $row['total_amount'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                            <a href="#" class="addPay">Add Payment</a>
                                            <a href="#" class="transDetails">Sale Details</a>
                                            <a href="#" class="productDetails">Product Details</a>
                                            <a href="#" class="payDetails">Payment Details</a>
                                            <a href="#" id="printReceipt">Print Receipt</a>
                                            <a href="#" id="quote">Quote</a>
                                            
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--ACTION AREA-->

    <!--Add Payment-->
    <div class="view-popup">
        <div class="popup-container addPayContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Add Payment</h2>
                        </div>

                        <div class="cash-pay-inputs">
                            <div class="cash-payment">
                                <div class="cash-input">
                                    <label for="cashInput">Cash:</label>
                                    <input type="number" id="cashInput" name="cash-account">
                                </div>
                                <div class="change-input">
                                    <label for="change">Change:</label>
                                    <input type="number" name="change" id="change">
                                </div>
                            </div>
                            <div class="bank-note-mobile">
                                <div class="mobile-bank">
                                    <div class="bank-input">
                                        <label for="bank">Bank:</label>
                                        <input type="number" name="bank" id="bank">
                                    </div>
                                    <div class="mobile-input">
                                        <label for="mobile">Mobile:</label>
                                        <input type="number" name="mobile" id="mobile">
                                    </div>
                                </div>
                                <div class="note-input">
                                    <label for="note">Note:</label>
                                    <textarea name="note" id="note" cols="30" rows="10"></textarea>
                                </div>
                            </div>

                            <div class="coupon-pay">
                                <div class="coupon-input">
                                    <label for="coupon">Coupon:</label>
                                    <input type="number" name="coupon" id="coupon">
                                </div>
                                <div class="coupon-customer">
                                    <label for="coupCust">Customer:</label>
                                    <input list="coupon-customer" id="coupCust">
                                    <datalist id="coupon-customer">
                                        <option value="Customer 1"></option>
                                        <option value="Customer 2"></option>
                                        <option value="Customer 4"></option>
                                        <option value="Customer 8"></option>
                                            
                                    </datalist>
                                </div>
                            </div>

                            <div class="other-pay">
                                <div class="other--input">
                                    <label for="">Other</label>
                                    <input type="number" name="account_id" id="accountId">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">
                        <div class="close-btn">
                            <button class="close-btn closeAddPay">CLOSE</button>
                        </div>
                        <div class="submit-btn">
                            <button class="submit-btn">ADD</button>
                        </div>
                    </div>

    
                </div>
            </div>
        </div>
    </div>

    <!--Transaction Details-->
    <div class="view-popup">
        <div class="popup-container transDetailsContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Sale Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Date Of Sale:</span>
                                <figure>21-02-2024</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Customer:</span>
                                <figure>Abou</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Contacts:</span>
                                <figure>
                                    <p>0786235689</p>
                                    <p>customer@email.com</p>
                                </figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Warehouse:</span>
                                <figure>KKOO Wh-234</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">User:</span>
                                <figure>Amina Staff</figure>
                            </div>
                        </div>
                    </div>

                    

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeTransDetails">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>

    <!--Product Details-->
    <div class="view-popup">
        <div class="popup-container productDetailsContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Product Details</h2>
                        </div>

                        <div class="product-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Unit Price</th>
                                        <th>Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Washing Basin</td>
                                        <td>20,000</td>
                                        <td>3</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>


                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeProductDetails">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>

    <!--Payment Details-->
    <div class="view-popup">
        <div class="popup-container payDetailsContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Payment Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Total Amount:</span>
                                <figure>300,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Amount Paid:</span>
                                <figure>120,000</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Type Of Transaction:</span>
                                <figure>Normal</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Amount Remaining:</span>
                                <figure>180,000</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">LPO NO:</span>
                                <figure>013</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">DN NO:</span>
                                <figure>017</figure>
                            </div>
                            <div class="div-3">
                                <span class="fixed-title">PROFORMA NO:</span>
                                <figure>210</figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Total Discount:</span>
                                <figure>11,000</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closePayDetails">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>



                    <!--Edit details-->
                    <div class="popup-container editContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form">
                                    <div class="form-input form-heading">
                                        <h2>Edit Sale Details</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Date:</label><br>
                                            <input type="date" name="date" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Customer:</label><br>
                                            <input list="customer" id="customerId" name="customer_id" required>
                                            <datalist id="customer">
                                                <option value="Washabi"></option>
                                                <option value="Bilo"></option>
                                                <option value="Kasandra"></option>
                                                <option value="Amy"></option>
                                            </datalist>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Warehouse:</label><br>
                                            <input list="warehouses" id="warehouseId" name="warehouse_id" required>
                                            <datalist id="warehouses">
                                                <option value="Warehouse A"></option>
                                                <option value="Warehouse B"></option>
                                                <option value="Warehouse X"></option>
                                                <option value="Warehouse Y"></option>
                                            </datalist>
                                        </div>


                                    </div>

                                    
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

    <!-- filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Cash Or Credit:</label><br>
                            <input list="cash-credit" class="datalist-input" id="cashCredit" name="cash_credit" autocomplete="off" required>

                            <datalist id="cash-credit">
                                <option value="Cash"></option>
                                <option value="Credit"></option>
                          
                            </datalist>
                        </div>


                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>



    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR ADD PAYMENT ****
            $('.addPay').on('click', function () {
                $('.addPayContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeAddPay').on('click', function () {
                $('.addPayContainer').fadeOut();
            });

            $('.addPay').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR TRANSACTION DETAIL ****
            $('.transDetails').on('click', function () {
                $('.transDetailsContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeTransDetails').on('click', function () {
                $('.transDetailsContainer').fadeOut();
            });

            $('.transDetails').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR PRODUCT DETAILS****
            $('.productDetails').on('click', function () {
                $('.productDetailsContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeProductDetails').on('click', function () {
                $('.productDetailsContainer').fadeOut();
            });

            $('.productDetails').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR PAYMENT DETAILS ****
            $('.payDetails').on('click', function () {
                $('.payDetailsContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closePayDetails').on('click', function () {
                $('.payDetailsContainer').fadeOut();
            });

            $('.payDetails').on('click', function () {
                $('.popup').addClass('active');
            });



        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>