<?php
// Include the database connection file
include('../../config.php');

function generatePayCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();
    
    // Concatenate the components to form the receipt code
    $payCode = 'pay-' . '-' . $timestamp;

    return $payCode;
}

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $dates = $_POST['dates'];
    $amount = $_POST['amount'];
    $type_id = $_POST['type_id'];
    $account_id = $_POST['account_id'];
    $note = $_POST['note'];

    $payCode = generatePayCode();

    // Retrieve user_id and warehouse_id from session
    session_start(); // Make sure to start the session
    $user_id = $_SESSION['user_id'];
    $warehouse_id = $_SESSION['warehouse_id'];

    // Insert data into the 'expense' table
    $sql = "INSERT INTO expense (code, dates, amount, type_id, user_id, account_id, warehouse_id, note) VALUES ('$code','$dates', '$amount', '$type_id', '$user_id', '$account_id', '$warehouse_id', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        $paymentSql = "INSERT INTO payments (code, pay_code, dates, discount, amount, account_id, warehouse_id, user_id, note, lpo_no, proforma_no, dn_no, trans_id) 
                        VALUES ('$code', '$payCode', '$dates', '0', '$amount', '1', '$warehouse_id', '1', '$note', '0', '0', '0', '6')";
        $conn->query($paymentSql);
        header("location: view.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}


// Retrieve type data for dropdown
$type_query = "SELECT id, name FROM type";
$type_result = $conn->query($type_query);
$types = $type_result->fetch_all(MYSQLI_ASSOC);

// Retrieve account data for dropdown
$account_query = "SELECT id, name FROM account";
$account_result = $conn->query($account_query);
$accounts = $account_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);



// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Expensia';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--add details-->
                    <div class="popup-container" id="addContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form horizontal-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Expense</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Date:</label><br>
                                            <input type="date" name="dates" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Expense Type:</label><br>
                                            <input list="type" id="typeId" name="type_id" required>
                                            <datalist id="type">
                                                <?php
                                                    foreach ($types as $type) {
                                                        echo "<option value='{$type['id']}'>{$type['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">Amount:</label><br>
                                            <input type="number" name="amount">
                                        </div>

                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Account:</label><br>
                                            <input list="accounts" id="accountId" name="account_id" required>
                                            <datalist id="accounts">
                                                <?php
                                                    foreach ($accounts as $account) {
                                                        echo "<option value='{$account['id']}'>{$account['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Warehouse:</label><br>
                                            <input list="warehouses" id="warehouseId" name="warehouse_id" required>
                                            <datalist id="warehouses">
                                                <?php
                                                    foreach ($warehouses as $warehouse) {
                                                        echo "<option value='{$warehouse['id']}'>{$warehouse['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>


                                    </div>

                                    <div class="input-row">
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="note"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeBtn" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="filter--btn" style="display:none">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Code</th>                      
                        <th>Expense Type</th>
                        <th>Amount</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT 
                            expense.id as id,
                            expense.code as code, 
                            dates, 
                            type.name as type_name, 
                            amount 
                            FROM expense
                            INNER JOIN type ON expense.type_id = type.id
                            ORDER BY dates ASC";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td><?php echo $row['dates'];?></td>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['type_name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['amount']);?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                            <a href="#" class="delete-btn deleteBtn">Delete</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Expense Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Date:</span>
                                <figure>27-02-2024</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Expense-type:</span>
                                <figure>Transport</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Amount:</span>
                                <figure>35,000</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Account:</span>
                                <figure>Cash</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Warehouse:</span>
                                <figure>WH-3</figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


                    <!--Edit details-->
                    <div class="popup-container editContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form">
                                    <div class="form-input form-heading">
                                        <h2>Edit Expense Details</h2>
                                    </div>

                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Expense Type:</label><br>
                                            <input list="type" id="typeId" name="type_id" required>
                                            <datalist id="type">
                                                <option value="Transport"></option>
                                                <option value="Electricity"></option>
                                                <option value="Rent"></option>
                                                <option value="Internet"></option>
                                            </datalist>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">Amount:</label><br>
                                            <input type="number" name="amount">
                                        </div>

                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Account:</label><br>
                                            <input list="accounts" id="accountId" name="account_id" required>
                                            <datalist id="accounts">
                                                <option value="Account A"></option>
                                                <option value="Account B"></option>
                                                <option value="Account X"></option>
                                                <option value="Account Y"></option>
                                            </datalist>
                                        </div>

                                        <div class="form-input text-input">
                                            <label for="">Warehouse:</label><br>
                                            <input list="warehouses" id="warehouseId" name="warehouse_id" required>
                                            <datalist id="warehouses">
                                                <option value="Warehouse A"></option>
                                                <option value="Warehouse B"></option>
                                                <option value="Warehouse X"></option>
                                                <option value="Warehouse Y"></option>
                                            </datalist>
                                        </div>


                                    </div>

                                    <div class="input-row">
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="" id="" cols="20" rows="3"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

    <!-- Transaction filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Expense-type:</label><br>
                            <input list="expenses" class="datalist-input" id="expensesId" name="expenses_id" autocomplete="off" required>

                            <datalist id="expenses">
                                <option value="Transport"></option>
                                <option value="Rent"></option>
                                <option value="Internet"></option>
                            </datalist>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A"></option>
                                <option value="Warehouse X"></option>
                                <option value="Warehouse i"></option>
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>



    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

             // FOR ADD BUTTON ****
             $('#addBtn').on('click', function () {
                $('#addContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBtn').on('click', function () {
                $('#addContainer').fadeOut();
            });

            $('#addBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>