<?php
// Include the database connection file
include('../../config.php');

function generatePayCode() {
    // Generate a receipt code using the specified formula
    $timestamp = time();
    
    // Concatenate the components to form the receipt code
    $payCode = 'pay-' . '-' . $timestamp;

    return $payCode;
}

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $dates = $_POST['date'];
    $from_customer_id = $_POST['from_customer_id'];
    $to_customer_id = $_POST['to_customer_id'];
    $user_id = '1';
    $account_id = $_POST['account_id'];
    $warehouse_id = $_POST['warehouse_id'];
    $amount = $_POST['amount'];
    $note = $_POST['note'];

    $payCode = generatePayCode();

    // Insert data into the 'product' table
    $sql = "INSERT INTO coupon (code, dates, from_customer_id, to_customer_id, user_id, account_id, warehouse_id, amount, note) VALUES 
                               ('$code','$dates', '$from_customer_id', '$to_customer_id', '$user_id', '$account_id', '$warehouse_id', '$amount', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        $paymentSql = "INSERT INTO payments (code, pay_code, dates, discount, amount, account_id, warehouse_id, user_id, note, lpo_no, proforma_no, dn_no, trans_id) 
                        VALUES ('$code', '$payCode', '$dates', '0', '$amount', '1', '$warehouse_id', '1', '$note', '0', '0', '0', '8')";
        $conn->query($paymentSql);
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Retrieve type user for dropdown
// $user_query = "SELECT id, name FROM user";
// $user_result = $conn->query($user_query);
// $users = $user_result->fetch_all(MYSQLI_ASSOC);

// Retrieve account data for dropdown
$account_query = "SELECT id, name FROM account";
$account_result = $conn->query($account_query);
$accounts = $account_result->fetch_all(MYSQLI_ASSOC);

// Retrieve warehouse data for dropdown
$warehouse_query = "SELECT id, name FROM warehouse";
$warehouse_result = $conn->query($warehouse_query);
$warehouses = $warehouse_result->fetch_all(MYSQLI_ASSOC);

// Retrieve customer data for dropdown
$customer_query = "SELECT id, name FROM customer";
$customer_result = $conn->query($customer_query);
$customers = $customer_result->fetch_all(MYSQLI_ASSOC);



// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
    <?php
       $title = 'Coupon';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--add details-->
                    <div class="popup-container" id="addContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form horizontal-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Coupon Details</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Date:</label><br>
                                            <input type="date" name="date" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">FROM:</label><br>
                                            <input list="from_customers" id="from_customerId" name="from_customer_id" autocomplete="off" required>
                
                                            <datalist id="from_customers">
                                                <?php
                                                    foreach ($customers as $customer) {
                                                        echo "<option value='{$customer['id']}'>{$customer['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">TO:</label><br>
                                            <input list="to_customers" id="to_customerId" name="to_customer_id" autocomplete="off" required>
                
                                            <datalist id="to_customers">
                                                 <?php
                                                    foreach ($customers as $customer) {
                                                        echo "<option value='{$customer['id']}'>{$customer['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Warehouse:</label><br>
                                            <input list="warehouses" id="warehouseId" name="warehouse_id" required>
                                            <datalist id="warehouses">
                                                <?php
                                                    foreach ($warehouses as $warehouse) {
                                                        echo "<option value='{$warehouse['id']}'>{$warehouse['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>
                                        <div class="form-input text-input">
                                            <label for="">Account:</label><br>
                                            <input list="accounts" id="accountId" name="account_id" required>
                                            <datalist id="accounts">
                                                <?php
                                                    foreach ($accounts as $account) {
                                                        echo "<option value='{$account['id']}'>{$account['name']}</option>";
                                                    }
                                                ?>
                                            </datalist>
                                        </div>

                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Amount:</label><br>
                                            <input type="number" name="amount" required>
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="note"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeBtn" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
                <!-- <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div> -->
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        
                        <th>Date</th>
                        <th>Code</th>
                        <th>From</th>
                        <th>TO</th>
                        <th>Amount</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT 
                                coupon.id,
                                coupon.dates,
                                coupon.code,
                                from_customer.name as from_customer_name, 
                                to_customer.name as to_customer_name, 
                                coupon.from_customer_id, 
                                coupon.to_customer_id, 
                                coupon.amount 
                            FROM coupon 
                            INNER JOIN customer as from_customer ON coupon.from_customer_id = from_customer.id
                            INNER JOIN customer as to_customer ON coupon.to_customer_id = to_customer.id
                            ORDER BY coupon.dates ASC";


                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['dates'];?></td>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['from_customer_name'];?></td>
                                <td><?php echo $row['to_customer_name'];?></td>
                                <td class="td-amount"><?php echo number_format($row['amount']);?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="viewBtn">View</a>
                                            <!-- data-id=" echo $row['id']; ?>" -->
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                

<!-- // Retrieve the coupon ID from the URL parameter
// $couponId = isset($_GET['id']) ? $_GET['id'] : '';

// Use $couponId in your SQL query to fetch specific coupon details
// $sql = "SELECT 
//             coupon.id,
//             coupon.dates,
//             coupon.code,
//             from_customer.name as from_customer_name, 
//             to_customer.name as to_customer_name, 
//             coupon.from_customer_id, 
//             coupon.to_customer_id, 
//             coupon.amount,
//             coupon.note
//         FROM coupon 
//         INNER JOIN customer as from_customer ON coupon.from_customer_id = from_customer.id
//         INNER JOIN customer as to_customer ON coupon.to_customer_id = to_customer.id
//         WHERE coupon.id = $couponId";

// $result = $conn->query($sql);

// if ($result->num_rows > 0) {
//     $row = $result->fetch_assoc();
//      -->

    <div class="view-section">
        <div class="view-heading">
            <h2>Coupon Details</h2>
        </div>

        <div class="view-div">
            <div class="div-1">
                <span class="fixed-title">Date:</span>
                <!-- <figure> echo $row['dates']; ?></figure> -->
                <figure>gkhhjhj</figure>
            </div>
            <div class="div-2">
                <span class="fixed-title">Code:</span>
                <!-- <figure>< echo $row['code']; ?></figure> -->
                <figure>ffsdfs</figure>
            </div>
        </div>

        <div class="view-div">
            <div class="div-1">
                <span class="fixed-title">From:</span>
                <!-- <figure>< echo $row['from_customer_name']; ?></figure> -->
                <figure>ghhj</figure>
            </div>
            <div class="div-2">
                <span class="fixed-title">To:</span>
                <!-- <figure>< echo $row['to_customer_name']; ?></figure> -->
                <figure>jjkkj</figure>
            </div>
        </div>

        <div class="view-div">
            <div class="div-1">
                <span class="fixed-title">Amount:</span>
                <!-- <figure>< echo $row['amount']; ?></figure> -->
                <figure>kjjkjh</figure>
            </div>
            <div class="div-2">
                <span class="fixed-title">Note:</span>
                <!-- <figure>< echo $row['note']; ?></figure> -->
                <figure>hjhjh</figure>
            </div>
        </div>
    </div>

    
<!-- // } -->

<!-- // Close the database connection -->
<!-- $conn->close(); -->



                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


                    <!--Edit details-->
                    <div class="popup-container editContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form">
                                    <div class="form-input form-heading">
                                        <h2>Edit Customer Details</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Phone no.:</label><br>
                                            <input type="number" name="phone" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Email:</label><br>
                                            <input type="number" name="email" required>
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Address:</label><br>
                                            <input type="number" name="address" required>
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="" id="" cols="20" rows="3"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

    <!-- Transaction filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Customer:</label><br>
                            <input list="Customers" class="datalist-input" id="customerId" name="customer_id" autocomplete="off" required>

                            <datalist id="Customers">
                                <option value="Kidimi"></option>
                                <option value="Antony"></option>
                                <option value="Karen"></option>
                            </datalist>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A"></option>
                                <option value="Warehouse X"></option>
                                <option value="Warehouse i"></option>
                            </datalist>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Transactions:</label><br>
                            <input list="transactions" class="datalist-input" id="trans-actions" name="trans-actions" autocomplete="off" required>

                            <datalist id="transactions">
                                <option value="Sale"></option>
                                <option value="Payments"></option>
                                
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


    
    <?php
    include('../../assets/components/scripts-1.php');
    ?>



<script>
    $(document).ready(function () {

        // FOR ADD BUTTON ****
        $('#addBtn').on('click', function () {
            $('#addContainer').fadeIn();
            $('.popup').addClass('active');
        });

        // Close the popup when the close button is clicked
        $('#closeBtn').on('click', function () {
            $('#addContainer').fadeOut();
        });

        // FOR EDIT BUTTON ****
        $('.editBtn').on('click', function () {
            $('.editContainer').fadeIn();
        });

        // Close the popup when the close button is clicked
        $('.closeEditBtn').on('click', function () {
            $('.editContainer').fadeOut();
        });

        // FOR VIEW BUTTON ****
        $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });
        // $('.viewBtn').on('click', function (e) {
        //     e.preventDefault();

        //     var couponId = $(this).data('id');
        //     var viewContainerURL = 'view.php?id=' + couponId;

        //     $('.viewContainer').load(viewContainerURL, function () {
        //         $(this).addClass('active').fadeIn();
        //     });
        // });

        // Close the popup when the close button is clicked
        $('.closeView').on('click', function () {
            $('.viewContainer').removeClass('active').fadeOut();
        });

        // FOR FILTER BUTTON ****
        $('#pageFilterBtn').on('click', function () {
            $('#filterContainer').fadeIn();
        });

        // Close the popup when the close button is clicked
        $('#closeFilter').on('click', function () {
            $('#filterContainer').fadeOut();
        });


        $('#exportBrand').on('click', function () {
            // Call the exported function with parameters specific to the page
            exportTableToPDF('view-table', 'Coupon Table', 'coupon_table.pdf');
        });


    });
</script>


    
    

    
    
    
    
    
    

</body>
</html>
