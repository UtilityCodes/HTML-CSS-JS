<?php
include '../../config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['product'])) {
    $productName = $_GET['product'];

    // Fetch product details based on the provided name or barcode
        $productDetailsQuery = "SELECT 
                                product.id as id,
                                product.name as name,
                                product.code as code,
                                product.buying_price as buying_price,
                                unit.name as unit_name
                            FROM product
                            INNER JOIN unit ON product.unit_id = unit.id
                            WHERE product.name = '$productName' OR product.code = '$productName'";
    $result = $conn->query($productDetailsQuery);

    if ($result && $result->num_rows > 0) {
        $productDetails = $result->fetch_assoc();

        // Return product details as JSON
        header('Content-Type: application/json');
        echo json_encode($productDetails);
    } else {
        // Product not found
        header("HTTP/1.1 404 Not Found");
        echo json_encode(['error' => 'Product not found']);
    }
} else {
    // Invalid request
    header("HTTP/1.1 400 Bad Request");
    echo json_encode(['error' => 'Invalid request']);
}

$conn->close();





