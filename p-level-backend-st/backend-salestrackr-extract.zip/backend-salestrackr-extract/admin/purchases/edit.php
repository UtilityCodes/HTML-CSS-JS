<?php
// Get the edited values from the form
$newDate = $_POST['date'];
$newCode = $_POST['code'];
$newSupplier = $_POST['supplier_id'];
$newWarehouse = $_POST['warehouse_id'];

// Assuming you have the purchase ID available
$purchaseId = $_POST['purchase_id'];

// Update purchase table
$updatePurchaseQuery = "UPDATE purchase SET dates = '$newDate', code = '$newCode', supplier_id = '$newSupplier', warehouse_id = '$newWarehouse' WHERE id = '$purchaseId'";
$conn->query($updatePurchaseQuery);

// Update payments table
$updatePaymentsQuery = "UPDATE payments SET code = '$newCode' WHERE code = '$oldCode'";
$conn->query($updatePaymentsQuery);

// Update unique_activity table
$updateUniqueActivityQuery = "UPDATE unique_activity SET code = '$newCode' WHERE code = '$oldCode'";
$conn->query($updateUniqueActivityQuery);

// Add other update queries for additional tables if needed

// Redirect to the view page or wherever you need to go after the update
header("Location: view.php");
exit();

