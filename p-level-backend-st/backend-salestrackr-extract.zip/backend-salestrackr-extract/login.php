<?php
// Include the database connection file
include('../../config.php');

session_start(); // Start the session

if (isset($_POST["submit"])) {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Perform authentication and retrieve user information
    $sql = "SELECT u.*, r.name AS role_name FROM user u
            INNER JOIN role r ON u.role_id = r.id
            WHERE u.name = '$username' AND u.passcode = '$password'";
    
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['warehouse_id'] = $user['warehouse_id'];
        $_SESSION['role'] = $user['role_name'];

        // Redirect based on user role
        switch ($_SESSION['role']) {
            case 'admin':
                header("location: admin/dashboard/dashboard.php");
                exit();
            case 'manager':
                header("location: manager/sales/view.php");
                exit();
            case 'staff':
                header("location: staff/sales/add.php");
                exit();
            default:
                // Handle unexpected roles
                break;
        }
    } else {
        // Handle unsuccessful login
        echo "Invalid username or password";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In | SalesTrackr</title>
    <link rel="stylesheet" href="assets/css/login.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="assets/images/st-logo.jpg" type="image/x-icon">
</head>
<body>
    <div class="wrapper">
        <form action="" method="post">
            <h1>Login</h1>
            <div class="input-box">
                <input type="text" name="username" placeholder="Username" required>
                <i class='bx bxs-user'></i>
            </div>
            <div class="input-box">
                <input type="password" name="password" placeholder="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>
            <button type="submit" class="btn" name="submit">Login</button>
        </form>
    </div>
</body>
</html>
