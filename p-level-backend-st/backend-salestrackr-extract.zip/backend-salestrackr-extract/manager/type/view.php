<?php
// Include the database connection file
include('../../config.php');

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];

    // Insert data into the 'brand' table
    $sql = "INSERT INTO type (code, name, note) VALUES ('$code', '$name', '$note')";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Type | Expense';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="typeBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--add details-->
                    <div class="popup-container" id="addTypeContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form vertical-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Expense Type Details</h2>
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Code</label><br>
                                        <input type="text" name="code">
                                    </div>
                                    <div class="form-input text-input">
                                        <label for="">Add Name</label><br>
                                        <input type="text" name="name" required>
                                    </div>
                                    <div class="form-input note-input">
                                        <label for="">Description</label><br>
                                        <textarea name="note" id=""></textarea>
                                    </div>
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeForm" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Note</th>
                        <th>Action</th>
                    </tr>
                </thead>

                 <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, name, note FROM type";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['name'];?></td>
                                <td><?php echo $row['note'];?></td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="edit-btn">Edit</a>
                                            <a href="#" class="filter-btn">Transactions</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>
            </table>
        </div>
    </section>

    <!--for edit-->
    <div class="edit-pop">
        <div class="popup-container" id="editContainer">
            <div class="popup view-pop">
                <div class="popup-content">
    
                    <form action="" class="sub-form vertical-form">
                        <div class="form-input form-heading">
                            <h2>Edit Expense Type Details</h2>
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Code</label><br>
                            <input type="text" name="code">
                        </div>
                        <div class="form-input text-input">
                            <label for="">Add Name</label><br>
                            <input type="text" name="name" required>
                        </div>
                        <div class="form-input note-input">
                            <label for="">Description</label><br>
                            <textarea name="" id="" cols="42" rows="3"></textarea>
                        </div>
                        <div class="form-btns">
                            <div class="close-btn">
                                <button id="editClose" class="close-btn">CLOSE</button>
                            </div>
                            <div class="submit-btn">
                                <button class="submit-btn">EDIT</button>
                            </div>
                        </div>
                    </form>
    
                </div>
            </div>
        </div>
    </div>


    <!--filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Transactions:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A"></option>
                                <option value="Warehouse X"></option>
                                <option value="Warehouse i"></option>
                            </datalist>
                        </div>
                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeTransFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>




    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

            // FOR ADD BUTTON ****
            $('#typeBtn').on('click', function () {
                $('#addTypeContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeForm').on('click', function () {
                $('#addTypeContainer').fadeOut();
            });

            $('#typeBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.edit-btn').on('click', function () {
                $('#editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#editClose').on('click', function () {
                $('#editContainer').fadeOut();
            });

            $('.edit-btn').on('click', function () {
                $('.popup').addClass('active');
            });




            // FOR FILTER BUTTON ****
            $('.filter-btn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeTransFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('.filter-btn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>