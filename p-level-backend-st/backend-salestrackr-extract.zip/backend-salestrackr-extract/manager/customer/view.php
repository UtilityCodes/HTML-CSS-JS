<?php
// Include the database connection file
include('../../config.php');

// Check if the form is submitted
if (isset($_POST["submit"])) {
    // Retrieve form data
    $code = $_POST['code'];
    $name = $_POST['name'];
    $note = $_POST['note'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Insert data into the 'brand' table
    $sql = "INSERT INTO customer (code, name, note, email, phone, address) VALUES ('$code', '$name', '$note', '$email', '$phone', '$address')";
    
    if ($conn->query($sql) === TRUE) {
        header("location: view.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<?php
       $title = 'Customerias';
       include('../../assets/components/head.php'); 
    ?>
<body>
    
        
    <?php
    include('../../assets/components/nav.php');
    ?>
            
        
   
    <section class="content">
        <?php
        include('../../assets/components/header.php');
        ?>

        <div class="computation-btns">
            <div class="manual-computations">
                <div class="add-btn">
                    <button type="button" id="addBtn" class="add-btn"><i class="fa fa-plus"></i></button>

                    <!--add details-->
                    <div class="popup-container" id="addContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form class="sub-form horizontal-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
                                    <div class="form-input form-heading">
                                        <h2>Add Customer Details</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Phone no.:</label><br>
                                            <input type="number" name="phone" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Email:</label><br>
                                            <input type="text" name="email" required>
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Address:</label><br>
                                            <input type="text" name="address" required>
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="note" id=""></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button id="closeBtn" class="close-btn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button name="submit" class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>
                <div class="filter--btn">
                    <button type="button" id="pageFilterBtn" class="add-btn">Filter</button>
                </div>
            </div>
            <?php
            include('../../assets/components/auto-comp.php');
            ?>
        </div>

        <div class="table-list">
            <table id="view-table" class="display">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Contacts</th>
                        <th>Credit</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                <?php 
                   include('../../config.php');
                   $sql = "SELECT code, name, phone, email FROM customer";
                   $result = $conn->query($sql);

                   if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        ?>

                            <tr>
                                <td class="td-width"><?php echo $row['code'];?></td>
                                <td><?php echo $row['name'];?></td>
                                <td>
                                    <p><?php echo $row['phone'];?></p>
                                    <p><?php echo $row['email'];?></p>
                                </td>
                                <td>0.00</td>
                                <td class="td-action">
                                    <div class="action">
                                        <button class="actionBtn"><i class="fa fa-eye"></i></button>
                                        <span class="action-dropdown">
                                            <a href="#" class="view-btn viewBtn">View</a>
                                            <a href="#" class="edit-btn editBtn">Edit</a>
                                        </span>
                                    </div>
                                </td>
                            </tr>

                        <?php  }
                    }?>
                    

                </tbody>

            </table>
        </div>
    </section>

    

    <!--View Popup-->
    <div class="view-popup">
        <div class="popup-container viewContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="view-section">
                        <div class="view-heading">
                            <h2>Customer Details</h2>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Name:</span>
                                <figure>Karen</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Code:</span>
                                <figure>1071</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Phone:</span>
                                <figure>0789654321</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Email:</span>
                                <figure>Customer@email.com</figure>
                            </div>
                        </div>
                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Address:</span>
                                <figure>Kariakoo</figure>
                            </div>
                            <div class="div-2">
                                <span class="fixed-title">Note:</span>
                                <figure>No Note</figure>
                            </div>
                        </div>

                        <div class="view-div">
                            <div class="div-1">
                                <span class="fixed-title">Debt:</span>
                                <figure>73,000</figure>
                            </div>
                            <div class="div-2" style="display: none;">
                                <span class="fixed-title"></span>
                                <figure></figure>
                            </div>
                        </div>
                    </div>

                    <div class="form-btns">

                        <div></div>
                        
                        <div class="close-btn">
                            <button class="close-btn closeView">CLOSE</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>


                    <!--Edit details-->
                    <div class="popup-container editContainer">
                        <div class="popup view-pop">
                            <div class="popup-content">

                                <form action="" class="sub-form horizontal-form">
                                    <div class="form-input form-heading">
                                        <h2>Edit Customer Details</h2>
                                    </div>
                                    <div class="input-row">
            
                                        <div class="form-input text-input">
                                            <label for="">Name:</label><br>
                                            <input type="text" name="name" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Code:</label><br>
                                            <input type="text" name="code">
                                        </div>
            
                                    </div>
            
                                    <div class="input-row">
                                        
                                        <div class="form-input text-input">
                                            <label for="">Phone no.:</label><br>
                                            <input type="number" name="phone" required>
                                        </div>
            
                                        <div class="form-input text-input">
                                            <label for="">Email:</label><br>
                                            <input type="number" name="email" required>
                                        </div>
            
                                    </div>

                                    <div class="input-row">

                                        <div class="form-input text-input">
                                            <label for="">Address:</label><br>
                                            <input type="number" name="address" required>
                                        </div>
                                        
                                        <div class="form-input note-input">
                                            <label for="">Description</label><br>
                                            <textarea name="" id="" cols="20" rows="3"></textarea>
                                        </div>
                                    </div>
            
                                    <div class="form-btns">
                                        <div class="close-btn">
                                            <button class="close-btn closeEditBtn">CLOSE</button>
                                        </div>
                                        <div class="submit-btn">
                                            <button class="submit-btn">ADD</button>
                                        </div>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

    <!-- Transaction filter popup-->
    <div class="view-popup">
        <div class="popup-container" id="filterContainer">
            <div class="popup view-pop">
                <div class="popup-content">

                    <div class="filter-section">
                        <div class="filter-title view-heading">
                            <h2>Filter:</h2>
                        </div>
                        <div class="filter-date">
                            <div class="from-date">
                                <label for="">FROM:</label>
                                <input type="date" name="from-date" id="fromDate">
                            </div>
                            <div class="to-date">
                                <label for="">TO:</label>
                                <input type="date" name="to-date" id="toDate">
                            </div>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Customer:</label><br>
                            <input list="Customers" class="datalist-input" id="customerId" name="customer_id" autocomplete="off" required>

                            <datalist id="Customers">
                                <option value="Kidimi"></option>
                                <option value="Antony"></option>
                                <option value="Karen"></option>
                            </datalist>
                        </div>
                        <div class="filter-datalist">
                            <label for="">Warehouse:</label><br>
                            <input list="warehouses" class="datalist-input" id="warehouse" name="warehouse" autocomplete="off" required>

                            <datalist id="warehouses">
                                <option value="Warehouse A"></option>
                                <option value="Warehouse X"></option>
                                <option value="Warehouse i"></option>
                            </datalist>
                        </div>

                        <div class="filter-datalist">
                            <label for="">Transactions:</label><br>
                            <input list="transactions" class="datalist-input" id="trans-actions" name="trans-actions" autocomplete="off" required>

                            <datalist id="transactions">
                                <option value="Sale"></option>
                                <option value="Payments"></option>
                                
                            </datalist>
                        </div>

                    </div>

                    <div class="form-btns">
                        
                        <div class="close-btn">
                            <button id="closeFilter" class="close-btn">CLOSE</button>
                        </div>

                        <div class="submit-btn">
                            <button class="submit-btn">FILTER</button>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>



    


    <?php
    include('../../assets/components/scripts-1.php');
    ?>



    <script>
        $(document).ready(function () {

             // FOR ADD BUTTON ****
             $('#addBtn').on('click', function () {
                $('#addContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeBtn').on('click', function () {
                $('#addContainer').fadeOut();
            });

            $('#addBtn').on('click', function () {
                $('.popup').addClass('active');
            });


            // FOR EDIT BUTTON ****
            $('.editBtn').on('click', function () {
                $('.editContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeEditBtn').on('click', function () {
                $('.editContainer').fadeOut();
            });

            $('.editBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR VIEW BUTTON ****
            $('.viewBtn').on('click', function () {
                $('.viewContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('.closeView').on('click', function () {
                $('.viewContainer').fadeOut();
            });

            $('.viewBtn').on('click', function () {
                $('.popup').addClass('active');
            });



            // FOR FILTER BUTTON ****
            $('#pageFilterBtn').on('click', function () {
                $('#filterContainer').fadeIn();
            });

            // Close the popup when the close button is clicked
            $('#closeFilter').on('click', function () {
                $('#filterContainer').fadeOut();
            });

            $('#pageFilterBtn').on('click', function () {
                $('.popup').addClass('active');
            });

        });
    </script>
    
    

    
    
    
    
    
    

</body>
</html>