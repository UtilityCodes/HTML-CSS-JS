
document.addEventListener('DOMContentLoaded', function() {
    var sidebar = document.getElementById('sidebar');
    var burgerIcon = document.getElementById('burger-icon');
    var closeIcon = document.querySelector('.nav-header .close');

    var userSpan = document.querySelector('.user');
    var userDropdown = document.querySelector('.user-dropdown');

    // Function to toggle the sidebar
    function toggleSidebar() {
        sidebar.classList.toggle('sidebar-opened');
    }

    // Event listener for burger icon
    burgerIcon.addEventListener('click', toggleSidebar);

    // Event listener for close icon
    closeIcon.addEventListener('click', toggleSidebar);

    // Function to toggle the user-dropdown
    function toggleUserDropdown() {
        userDropdown.classList.toggle('show-dropdown');
    }

    // Event listener for user span
    userSpan.addEventListener('click', toggleUserDropdown);

    // Close the dropdown if the user clicks outside of it
    window.addEventListener('click', function(event) {
        if (!event.target.matches('.user')) {
            if (userDropdown.classList.contains('show-dropdown')) {
                userDropdown.classList.remove('show-dropdown');
            }
        }
    });

    // Add click event listeners to main features with sub-features
    var submenuLinks = document.querySelectorAll('.main-menu');
    submenuLinks.forEach(function(submenuLink) {
        submenuLink.addEventListener('click', function(event) {
            event.preventDefault(); // Prevent the default behavior of the link
            var submenu = this.nextElementSibling; // Get the next sibling (ul) element
            submenu.classList.toggle('show-submenu'); // Toggle display for the submenu
        });
    });
});

