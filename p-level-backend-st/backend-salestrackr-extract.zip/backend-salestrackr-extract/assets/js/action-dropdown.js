$(document).ready(function() {
        // Toggle the action-dropdown for the clicked button
        $('.actionBtn').on('click', function () {
            // Find the closest .action element and then find its .action-dropdown
            $(this).closest('.action').find('.action-dropdown').toggleClass('show-dropdown');
        });

        // Close the action-dropdown if clicked outside of it
        $(document).on('click', function (e) {
            if (!$(e.target).closest('.action').length) {
                $('.action-dropdown').removeClass('show-dropdown');
            }
        });
});