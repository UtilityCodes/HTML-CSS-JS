    // Function to initialize DataTable
    $(document).ready(function() {
        $('#view-table').DataTable();
    });