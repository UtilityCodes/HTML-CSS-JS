// export-pdf.js

function exportTableToPDF(tableId, pdfTitle, pdfFileName) {
    // Initialize jsPDF
    var doc = new jsPDF();

    // Add a title to the PDF
    doc.text(pdfTitle, 14, 10);

    // Get the table as HTML
    var table = document.getElementById(tableId);

    // Convert the table to a data URL
    tableToDataURL(table).then(function (dataURL) {
        // Embed the data URL in the PDF
        doc.addImage(dataURL, 'JPEG', 10, 20);

        // Save the PDF
        doc.save(pdfFileName);
    });
}

function tableToDataURL(table) {
    // Use html2canvas to convert the table to a data URL
    return new Promise((resolve) => {
        html2canvas(table, {
            onrendered: function (canvas) {
                resolve(canvas.toDataURL('image/jpeg'));
            },
        });
    });
}
