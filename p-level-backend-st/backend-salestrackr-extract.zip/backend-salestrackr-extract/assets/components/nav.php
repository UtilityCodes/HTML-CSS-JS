<nav id="sidebar">
        <header class="left-header">
            <div class="nav-header">
                <img src="../../assets/images/st-logo.jpg" alt="">
                <span>SalesTrackr</span>
                <div class="close"><i class="fa fa-times"></i></div>
            </div>
        </header>
        
        <ul class="side-list">
            <li><a href="../../admin/dashboard/dashboard.php"><i class="fa fa-th"></i>Dashboard</a></li>
            <li><a href="" class="main-menu"><i class="fa fa-pencil-square-o"></i>Register</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/brand/view.php"><i class="fa fa-copyright"></i>Brand</a></li>
                    <li><a href="../../admin/category/view.php"><i class="fa fa-sitemap"></i>Category</a></li>
                    <li><a href="../../admin/product/view.php"><i class="fa fa-television"></i>Product</a></li>
                    <li><a href="../../admin/service/view.php"><i class="fa fa-motorcycle"></i>Service</a></li>
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-credit-card"></i>Purchases</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/purchases/add.php"><i class="fa fa-plus"></i>Add Purchases</a></li>
                    <li><a href="../../admin/purchases/view.php"><i class="fa fa-list-ol"></i>Purchase List</a></li>
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-shopping-cart"></i>Sales</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/sales/add.php"><i class="fa fa-plus"></i>Add Sales</a></li>
                    <li><a href="../../admin/sales/view.php"><i class="fa fa-list-ol"></i>Sale List</a></li>
                    <li><a href="../../admin/service-sale/add.php"><i class="fa fa-plus"></i>Add Service Sale</a></li>
                    <li><a href="../../admin/service-sale/view.php"><i class="fa fa-list-ol"></i>Service Sale List</a></li>
                    <li><a href="../../admin/coupon/view.php"><i class="fa fa-list-ol"></i>Coupon</a></li>
                </ul>
            </li>
            <!-- <li><a href="#"><i class="fa fa-quote-right"></i>Quotation</a></li> -->
            <li><a href="" class="main-menu"><i class="fa fa-undo"></i>Transactions</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/payment/view.php"><i class="fa fa-forward"></i>Payments</a></li>
                    <li><a href="../../admin/drawings/view.php"><i class="fa fa-backward"></i>Drawings</a></li>
                </ul>
            </li>
            <li><a href="../../admin/on-sale/view.php"><i class="fa fa-rocket"></i>On Sale</a></li>

            <li><a href="" class="main-menu"><i class="fa fa-undo"></i>Returns</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/purchase-return/add.php"><i class="fa fa-plus"></i>Add P Returns</a></li>
                    <li><a href="../../admin/purchase-return/view.php"><i class="fa fa-forward"></i>Purchase Returns</a></li>
                    <li><a href="../../admin/sale-return/add.php"><i class="fa fa-plus"></i>Add S Returns</a></li>
                    <li><a href="../../admin/sale-return/view.php"><i class="fa fa-backward"></i>Sale Returns</a></li>
                </ul>
            </li>
           
            <li><a href="" class="main-menu"><i class="fa fa-exchange"></i>Transfer</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/transfer/add.php"><i class="fa fa-plus"></i>Add Transfer</a></li>
                    <li><a href="../../admin/transfer/view.php"><i class="fa fa-list-ol"></i>Transfer List</a></li>
                    
                </ul>
            </li>
            <li><a href="" class="main-menu"><i class="fa fa-users"></i>People</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/customer/view.php"><i class="fa fa-user"></i>Customer</a></li>
                    <li><a href="../../admin/supplier/view.php"><i class="fa fa-user-o"></i>Supplier</a></li>
                    <li><a href="../../admin/user/view.php"><i class="fa fa-user-circle-o"></i>User</a></li>
                </ul>
            </li>
            
            <li><a href="" class="main-menu"><i class="fa fa-money"></i>Expenses</a>
                <ul class="sub-menu">
                    <li><a href="../../admin/type/view.php"><i class="fa fa-plus"></i>Type</a></li>
                    <li><a href="../../admin/expenses/view.php"><i class="fa fa-money"></i>Expenses</a></li>
                    
                </ul>
            </li>
            <li><a href="../../admin/warehouse/view.php"><i class="fa fa-building"></i>Warehouses</a></li>
        </ul>           
    </nav>
            