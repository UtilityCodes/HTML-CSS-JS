<?php
include('config.php');

// Check if the form is submitted for adding sales
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_sales'])) {
    $date = isset($_POST['date']) ? $_POST['date'] : null;
    $discount = isset($_POST['discount']) ? $_POST['discount'] : null;
    $total = isset($_POST['total']) ? $_POST['total'] : null;

    if ($date !== null && $total !== null && isset($_POST['productid']) && isset($_POST['quantity'])) {
        // Generate a receipt code
        $receiptCode = generateReceiptCode();

        // Insert sales information into the 'sales' table with receipt code
        $salesSql = "INSERT INTO sales (date, discount, amount, receipt) VALUES ('$date', '$discount', '$total', '$receiptCode')";

        if ($conn->query($salesSql) === TRUE) {
            // Retrieve the last inserted sales ID
            $salesId = $conn->insert_id;

            // Iterate over the rows in the table
            for ($i = 0; $i < count($_POST['productid']); $i++) {
                $productid = $_POST['productid'][$i];
                $quantity = $_POST['quantity'][$i];

                // Insert product sales information into the 'productsales' table with receipt code
                $productsalesSql = "INSERT INTO productsales (productid, quantity, receipt) VALUES ('$productid', '$quantity', '$receiptCode')";
                $conn->query($productsalesSql);
            }

            // Update sales amount in the 'sales' table
            $updateSalesSql = "UPDATE sales SET amount = '$total' WHERE id = '$salesId'";
            $conn->query($updateSalesSql);

            // Sales added successfully
            header("Refresh:0");
        } else {
            echo "Error: " . $salesSql . "<br>" . $conn->error;
        }
    } else {
        echo "Error: 'date', 'total', 'productid', or 'quantity' is not set.";
    }
}

function generateReceiptCode() {
    // Generate a receipt code using the specified formula
    $randomFourDigitNumber = sprintf('%04d', mt_rand(1, 9999)); // Generate a random four-digit number
    $timestamp = time();
    
    // Concatenate the components to form the receipt code
    $receiptCode = 'sales-' . $randomFourDigitNumber . '-' . $timestamp . '-001';

    return $receiptCode;
}

// Fetch product data for the datalist
$productData = $conn->query("SELECT id, name, barcode, price FROM product");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Sales</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        #container {
            display: flex;
            height: 100vh;
        }

        #left-side {
            flex: 65%;
            background-color: #f0f0f0;
            padding: 20px;
        }

        #right-side {
            flex: 35%;
            background-color: #ddd;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        input, button {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<form method="post">
    <div id="container">
        <div id="left-side">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>

            <label for="search">Search:</label>
            <input list="products" id="search" name="search" placeholder="Type to search..." oninput="handleProductSelection()">
            <datalist id="products">
                <?php
                $productData->data_seek(0); // Reset the pointer to the beginning
                while ($row = $productData->fetch_assoc()) {
                    echo "<option value=\"{$row['name']}\">";
                    echo "<option value=\"{$row['barcode']}\">";
                }
                ?>
            </datalist>

            <table>
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Product</th>
                        <th>Unit</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody id="productTableBody"></tbody>
            </table>
        </div>

        <div id="right-side">
            <label for="subtotal">Subtotal:</label>
            <p id="subtotal">$0.00</p>

            <label for="discount">Discount:</label>
            <input type="text" id="discount" name="discount" placeholder="Enter discount..." oninput="updateTotal()">

            <label for="total">Total:</label>
            <p id="total">$0.00</p>

            <input type="hidden" id="totalInput" name="total">

            <button type="submit" name="add_sales">Pay</button>
        </div>
    </div>
</form>




<script>
    function handleProductSelection() {
        var selectedProduct = document.getElementById('search').value;

        // AJAX request to fetch product details
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                if (xhr.status == 200) {
                    var productDetails = JSON.parse(xhr.responseText);
                    displayProductDetails(productDetails);
                } else {
                    console.error('Error fetching product details:', xhr.statusText);
                    // Handle the error here, e.g., display an alert to the user
                }
            }
        };

        xhr.open("GET", "get_product_details.php?product=" + selectedProduct, true);
        xhr.send();
    }

    function displayProductDetails(productDetails) {
        if (productDetails.error) {
            // Handle error, e.g., display an alert
            console.error('Error:', productDetails.error);
        } else {
            var table = document.getElementById('productTableBody');
            var newRow = table.insertRow();
            newRow.innerHTML = `<td>${productDetails.id}</td>
                                <td>${productDetails.name}</td>
                                <td>Each</td>
                                <td>${productDetails.price}</td>
                                <td><input type="number" name="quantity[]" value="1" min="1" oninput="updateAmount(this)"></td>
                                <td>${productDetails.price}</td>
                                <input type="hidden" name="productid[]" value="${productDetails.id}">`;

            // Update subtotal and total values
            updateTotal();
        }
    }

    function updateAmount(input) {
        var row = input.parentNode.parentNode;
        var price = parseFloat(row.cells[3].textContent);
        var quantity = parseInt(input.value);
        var amount = price * quantity;
        row.cells[5].textContent = amount.toFixed(2);

        // Update subtotal and total values
        updateTotal();
    }

    function updateTotal() {
        var table = document.getElementById('productTableBody');
        var rows = table.querySelectorAll('tr');
        var subtotal = 0;

        rows.forEach(function (row) {
            var amount = parseFloat(row.cells[5].textContent);
            subtotal += amount;
        });

        var discount = parseFloat(document.getElementById('discount').value) || 0;
        var total = subtotal - discount;

        document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
        document.getElementById('total').textContent = `$${total.toFixed(2)}`;
    }

    
</script>
</body>
</html>



