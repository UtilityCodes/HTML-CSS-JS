<?php
include('config.php'); // Include the database connection file

// Check if the form is submitted for adding a product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $barcode = $_POST['barcode'];
    $price = $_POST['price'];

    // Insert new product into the 'product' table
    $sql = "INSERT INTO product (name, barcode, price) VALUES ('$name', '$barcode', '$price')";

    if ($conn->query($sql) === TRUE) {
        // Product added successfully
        header("Refresh:0"); // Refresh the page to display the updated product list
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Page</title>
    <style>
        /* Add your CSS styling here */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        #popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ccc;
            z-index: 999;
        }
    </style>
</head>
<body>
    <h1>Product Page</h1>

    <!-- Display products in a table -->
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Barcode</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch and display products from the 'product' table
            $result = $conn->query("SELECT * FROM product");
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['barcode']}</td>
                        <td>{$row['price']}</td>
                    </tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Add Button to open the popup -->
    <button onclick="openPopup()">Add Product</button>

    <!-- Popup for adding a new product -->
    <div id="popup">
        <h2>Add Product</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="barcode">Barcode:</label>
            <input type="text" id="barcode" name="barcode" required>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" step="0.01" required>

            <button type="submit" name="add_product">Add</button>
        </form>
        <button onclick="closePopup()">Close</button>
    </div>

    <script>
        // JavaScript functions to show and hide the popup
        function openPopup() {
            document.getElementById("popup").style.display = "block";
        }

        function closePopup() {
            document.getElementById("popup").style.display = "none";
        }
    </script>
</body>
</html>
